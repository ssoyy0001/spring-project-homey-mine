package org.homey.mapper;


import org.homey.domain.OdReviewVO;
import org.homey.domain.SoCriteria;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;


import lombok.Setter;
import lombok.extern.log4j.Log4j;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration("file:src/main/webapp/WEB-INF/spring/root-context.xml")
@Log4j
public class OdReviewMapperTests {
	@Setter(onMethod_ = @Autowired)
	private OdReviewMapper odReviewMapper;
	
	@Test
	public void testInsert() {		//리뷰 등록 테스트
		OdReviewVO orvo = new OdReviewVO();
		
		orvo.setMid("ssoyy00010001");
		orvo.setOdNo(141);
		orvo.setOrTitle("원데이클래스 참여후기");
		orvo.setOrContent("똑똑하게 시작하는 원데이클래스 참여하고 왔어요! \\n유용했어요~.");
		
		odReviewMapper.insertSelectKey(orvo);
		log.info("--------------------------");
		log.info(orvo);
	}
	
	
	
	public void testSelectAllPaging() {		//메서드 이름 자유, 페이징 전체조회 메서드
		
		SoCriteria c = new SoCriteria(8,2);	//amount 2, pageNum 2 로 테스트해봄
		odReviewMapper.selectAllPaging(c).forEach(orvo -> log.info(orvo));			//람다 사용해서 한 줄씩 나오도록
		
		log.info("--------------------------");
		log.info("전체 게시물 수 : " + odReviewMapper.totalCount(c));
		log.info("--------------------------");
	}
	
	
	
	public void testUpdateHit() {
		
		log.info("--------------------------");
		log.info("UPDATEHIT COUNT : " + odReviewMapper.updateHit(8));
		
	}
	
	
	public void testDelete() {		//메서드 이름 자유, 게시글 삭제 메서드
		log.info("DELETE COUNT : " + odReviewMapper.delete(9));
	}
	
	
	
	public void testUpdate() {		//메서드 이름 자유, 게시글 수정 메서드
		OdReviewVO orvo = odReviewMapper.select(9);
		
		orvo.setOrTitle("호미호미 클래스를 수정");
		orvo.setOrContent("호미호미 클래스 리뷰 후기를 수정중");
		
		log.info("UPDATE COUNT : " + odReviewMapper.update(orvo));
	}
	
	
	
	public void testSelect() {		//메서드 이름 자유, 개별조회 메서드
		log.info("--------------------------");
		log.info(odReviewMapper.select(5));		//No는 일단 임의로 씀
		log.info("--------------------------");
	}
	
	
	public void testSelectMine() {		//내가 쓴 리뷰 전체조회 테스트
		
		SoCriteria c = new SoCriteria();	//amount 8, pageNum 1 로 테스트해봄
	    
		log.info("--------------------------");
		odReviewMapper.selectMine("ssoyy00010001", c).forEach(orvo -> log.info(orvo));			//람다 사용해서 한 줄씩 나오도록
		
	}
	
	
	public void testMineCount() {		//내가 쓴 리뷰 개수 테스트
		
		SoCriteria c = new SoCriteria();
		
		log.info("--------------------------");
		log.info(odReviewMapper.mineCount("user000000", c));
		
	}
	
	
	
	public void testCount() {		//리뷰 전체 개수 테스트
		SoCriteria c = new SoCriteria();	//amount 2, pageNum 2 로 테스트해봄
		
		log.info("--------------------------");
		log.info(odReviewMapper.totalCount(c));
		
	}
	
	

	
	
	
//	public void testSearch() {
//		Criteria cri = new Criteria();
//
////		cri.setType("W");				//1. 작성자에서 검색
//		cri.setType("TC");				//2. 제목 또는 내용에서 검색
//		cri.setKeyword("update");
//		
//		boardMapper.selectAllPaging(cri).forEach(bvo -> log.info(bvo));	
//		log.info("------------------------");
//		log.info("전체 게시물 수 : " + boardMapper.totalCount(cri));
//		log.info("--------------------------");
//		
//	}
	

	
}
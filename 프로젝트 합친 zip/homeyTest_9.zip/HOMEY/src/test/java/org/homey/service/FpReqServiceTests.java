package org.homey.service;

import static org.junit.Assert.assertNotNull;

import org.homey.domain.FPReqVO;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import lombok.Setter;
import lombok.extern.log4j.Log4j;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration("file:src/main/webapp/WEB-INF/spring/root-context.xml")
@Log4j
public class FpReqServiceTests {
	
	@Setter(onMethod_ = @Autowired)
	private FPReqService fpReqService;
	
	@Test
	public void testListMine() {			//나의 제품 나눔 신청목록 조회
		
		log.info("--------------------------");
		fpReqService.fpListMine("tester").forEach(odrvo -> log.info(odrvo));
			
	}
	
	
	public void testList() {					//"모든 제품 나눔"의 당첨자 전체조회 테스트
		
		log.info("--------------------------");
		fpReqService.fpWinListAll().forEach(odrvo -> log.info(odrvo));
			
	}
	
	
	
	public void testListPaging() {		//"특정 제품 나눔"의 당첨자 전체조회 테스트
		
		log.info("--------------------------");
		fpReqService.fpWinList(1).forEach(odrvo -> log.info(odrvo));
			
	}
	
	
	public void testDoubleCheck() {		//제품 나눔 중복신청 여부 확인 테스트
		
		log.info("--------------------------");
		log.info("중복 건수 : " + fpReqService.fpReqCheck(3, "tester"));		// 0 출력됨

	}
	
	
	public void testRegister() {				//제품 나눔 신청 테스트
		
		FPReqVO fprvo = new FPReqVO();
		
		fprvo.setFpNo(1);
		fprvo.setMid("tester");
		
		log.info("등록 성공 : " + fpReqService.fpReqRegister(fprvo));
		
	}
	
	
	public void testExist() {					//fpReqService가 잘 만들어졌는지 확인
		assertNotNull(fpReqService);		
		log.info(fpReqService);
	}

	
	
}

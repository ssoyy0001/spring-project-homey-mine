package org.homey.mapper;


import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import org.homey.domain.SoCriteria;
import org.homey.domain.OnedayVO;

import lombok.Setter;
import lombok.extern.log4j.Log4j;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration("file:src/main/webapp/WEB-INF/spring/root-context.xml")
@Log4j
public class OnedaytMapperTests {
	
	@Setter(onMethod_ = @Autowired)
	private OnedayMapper onedayMapper;
	
	@Test	
	public void testSelectAllPaging() {		//원데이클래스 게시글 전체조회 테스트
		
		SoCriteria c = new SoCriteria();				//amount 8, pageNum 1 로 테스트해봄
		onedayMapper.odSelectAllPaging(c).forEach(odvo -> log.info(odvo));			//람다 사용해서 한 줄씩 나오도록
		
		log.info("--------------------------");
		c = new SoCriteria(2, 2);					//amount 2, pageNum 2 로 테스트해봄
		onedayMapper.odSelectAllPaging(c).forEach(odvo -> log.info(odvo));			//람다 사용해서 한 줄씩 나오도록
		

		log.info("--------------------------");
		log.info("등록된 전체 상품 수 : " + onedayMapper.odTotalCount(c));					//전체 상품 수 잘 불러오는지도 테스트
		log.info("--------------------------");
	}
	
	
	public void testSelect() {						//원데이클래스 게시글 개별조회 테스트
	log.info("--------------------------");
	log.info(onedayMapper.odSelect(10));
	
	//onedayMapper.odSelect(10) 					//실행은 되는데, 콘솔에는 안찍히는 이유가 뭘까?
	log.info("--------------------------");
}
	
	
	public void testDelete() {		//원데이클래스 게시글 삭제 테스트
		log.info("DELETE COUNT : " + onedayMapper.odDelete(7));
	}
	
	
	public void testUpdate() {		//원데이클래스 게시글 수정 테스트
		OnedayVO odvo = new OnedayVO();
		
		odvo.setOdNo(7);
		odvo.setOdTitle("(수정테스트)소가구 DIY 원데이클래스 진행합니다~");
		odvo.setOdContent("안녕하세요! 저희 HOMEY에서 <스타일링별 가구 배치 원데이클래스> 를 진행합니다. ^^\r\n"
									+ "OOO에 있어서 OOO 때문에 고민이셨던 분들이 참여해보시면 좋을 것 같아요~ \r\n"
									+ "OOO에서 ㅁㅁㅁㅁ로 활동중이신 김땡땡 전문가님이 진행하시는 클래스입니다.\r\n");
		odvo.setOdName("소가구 DIY 원데이클래스");
		odvo.setOdDate("2023-10-17 14:00");
		odvo.setOdPlace("호미 본사 2층 시청각실");
		odvo.setOdTime("1시간 30분");
		odvo.setOdPeople(4);
		odvo.setOdMc("김OO님");
		odvo.setOdDeadline("2023-10-24");
		
		odvo.setOdState(0);
		odvo.setMid("tester");
		odvo.setOdImg("이미지 주소");

		log.info("UPDATE COUNT : " + onedayMapper.odUpdate(odvo));
	}
	
	
	
	public void testInsert() {		//원데이클래스 게시글 추가 테스트
		OnedayVO odvo = new OnedayVO();
		
		odvo.setOdTitle("소가구 DIY 원데이클래스 진행합니다~");
		odvo.setOdContent("저희 HOMEY에서 <스타일링별 가구 배치 원데이클래스> 를 진행합니다. ^^\r\n"
									+ "OOO에 있어서 OOO 때문에 고민이셨던 분들이 참여해보시면 좋을 것 같아요~ \r\n"
									+ "OOO에서 ㅁㅁㅁㅁ로 활동중이신 김땡땡 전문가님이 진행하시는 클래스입니다.\r\n");
		odvo.setOdName("소가구 DIY 원데이클래스");
		odvo.setOdDate("2023-10-17 14:00");
		odvo.setOdPlace("호미 본사 2층 시청각실");
		odvo.setOdTime("1시간 30분");
		odvo.setOdPeople(4);
		odvo.setOdMc("김OO님");
		odvo.setOdDeadline("2023-10-24");
		
		odvo.setOdState(0);
		odvo.setMid("tester");
		odvo.setOdImg("이미지 주소");
	

		onedayMapper.odInsert(odvo);
		log.info("--------------------------");
		log.info(odvo);
	}



	
}
package org.homey.service;

import static org.junit.Assert.assertNotNull;

import org.homey.domain.SoCriteria;
import org.homey.domain.FreePdtVO;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import lombok.Setter;
import lombok.extern.log4j.Log4j;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration("file:src/main/webapp/WEB-INF/spring/root-context.xml")
@Log4j
public class FreePdtServiceTests {
	
	@Setter(onMethod_ = @Autowired)
	private FreePdtService freePdtService;
	
	@Test
	public void testModify() {													//제품나눔 게시글 수정
		
		FreePdtVO fpvo = freePdtService.fpView(6);
		
		if(fpvo == null) {			//fpNo가 6인 게시물이 없다면 리턴
			return;
		}
		
		fpvo.setFpTitle("미니멀한 수납을 도와주는 미니선반 나눔");
		fpvo.setFpContent("저희 HOMEY에서 <OO에디션 미니선반 DIY키트> 를 나눔합니다~\r\n"
								+ "OOO에 있어서 OOO 때문에 고민이셨던 분, OO한 자신만의 가구를 사용해보고 싶었던 분들이 사용해보시면 좋을 것 같아요 :)");
		fpvo.setFreePdt("미니선반");
		fpvo.setFpPeople(6);
		fpvo.setFpDeadline("2023/10/10");
		fpvo.setFpGetDate("2023/11/10");
		fpvo.setFpGetPlace("호미 본사 2층 시청각실");
		fpvo.setMid("tester");
		fpvo.setFpImg("이미지 주소");
		
		log.info("UPDATE RESULT : " + freePdtService.fpModify(fpvo));
	}
	
	
	
	public void testRemove() {							//제품나눔 게시글 삭제
		log.info("DELETE RESULT : " + freePdtService.fpRemove(7));
	}
	
	
	
	public void testRegister() {							//제품나눔 게시글 등록
		
		FreePdtVO fpvo = new FreePdtVO();
		
		fpvo.setFpTitle("미니멀한 수납을 도와주는 미니선반 나눔");
		fpvo.setFpContent("저희 HOMEY에서 <OO에디션 미니선반 DIY키트> 를 나눔합니다~\r\n"
								+ "OOO에 있어서 OOO 때문에 고민이셨던 분, OO한 자신만의 가구를 사용해보고 싶었던 분들이 사용해보시면 좋을 것 같아요 :)");
		fpvo.setFreePdt("미니선반");
		fpvo.setFpPeople(6);
		fpvo.setFpDeadline("2023/10/10");
		fpvo.setFpGetDate("2023/11/10");
		fpvo.setFpGetPlace("호미 본사 2층 시청각실");
		fpvo.setMid("tester");
		fpvo.setFpImg("이미지 주소");

		
		log.info("등록 성공 : " + freePdtService.fpRegister(fpvo) ) ;
	}
	
	
	
	public void testView() {								//제품나눔 게시글 상세조회
		log.info(freePdtService.fpView(1));
	}
	
	
	
	public void testListPaging() {						//제품 나눔 게시글 전체조회
		log.info("-------------------------");
		SoCriteria cri = new SoCriteria(2, 2);
		freePdtService.fpListPaging(cri).forEach(fpvo -> log.info(fpvo));
		log.info("-------------------------");
	}
	
	
	public void testCount() {								//제품 나눔 게시글 개수
		log.info("-------------------------");
		SoCriteria cri = new SoCriteria();
		log.info(freePdtService.fpTotalCount(cri));
		log.info("-------------------------");
		
	}
	
	
	public void testExist() {								//freePdtService가 잘 만들어졌는지 확인
		assertNotNull(freePdtService);	
		log.info(freePdtService);
	}
	
	
}

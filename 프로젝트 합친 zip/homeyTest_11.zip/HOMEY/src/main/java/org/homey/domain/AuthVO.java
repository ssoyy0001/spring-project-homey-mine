package org.homey.domain;

import lombok.Data;

@Data
public class AuthVO {
	private String mid;
	private String auth;
}

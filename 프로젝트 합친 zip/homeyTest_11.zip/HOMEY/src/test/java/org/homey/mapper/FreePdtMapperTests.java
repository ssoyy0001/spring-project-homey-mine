package org.homey.mapper;


import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import org.homey.domain.SoCriteria;
import org.homey.domain.FreePdtVO;

import lombok.Setter;
import lombok.extern.log4j.Log4j;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration("file:src/main/webapp/WEB-INF/spring/root-context.xml")
@Log4j
public class FreePdtMapperTests {
	
	@Setter(onMethod_ = @Autowired)
	private FreePdtMapper freePdtMapper;
	
	@Test
	public void plusNowPeople() {			//'현재 신청자 수' 증가
		log.info("SUCCESS COUNT : " + freePdtMapper.plusNowPeople(2));
	}
	
	
	public void testSelectAllPaging() {		//제품 나눔 게시글 전체조회 테스트
	
		SoCriteria c = new SoCriteria();				//amount 8, pageNum 1 로 테스트해봄
		freePdtMapper.fpSelectAllPaging(c).forEach(fpvo -> log.info(fpvo));			//람다 사용해서 한 줄씩 나오도록
		
		log.info("--------------------------");
		c = new SoCriteria(2, 2);					//amount 2, pageNum 2 로 테스트해봄
		freePdtMapper.fpSelectAllPaging(c).forEach(fpvo -> log.info(fpvo));			//람다 사용해서 한 줄씩 나오도록
		
	
		log.info("--------------------------");
		log.info("등록된 전체 상품 수 : " + freePdtMapper.fpTotalCount(c));					//전체 상품 수 잘 불러오는지도 테스트
		log.info("--------------------------");
	}
	
	
	public void testSelect() {						//제품 나눔 게시글 개별조회 테스트
		log.info("--------------------------");
		log.info(freePdtMapper.fpSelect(7));
		
		//onedayMapper.odSelect(10) 					//실행은 되는데, 콘솔에는 안찍히는 이유가 뭘까?
		log.info("--------------------------");
	}
	
	public void testDelete() {		//제품 나눔 게시글 삭제 테스트
		log.info("DELETE COUNT : " + freePdtMapper.fpDelete(8));
	}
	
	

	public void testUpdate() {		//제품 나눔 게시글 수정 테스트
		FreePdtVO fpvo = new FreePdtVO();
		
		fpvo.setFpNo(1);
		fpvo.setFpTitle("내가 만든!!!! 나만의 가구를 만들어보자! 미니선반 DIY키트 나눔");
		fpvo.setFpContent("수정테스트. 저희 HOMEY에서 <OO에디션 미니선반 DIY키트> 를 나눔합니다~\r\n"
								+ "OOO에 있어서 OOO 때문에 고민이셨던 분, OO한 자신만의 가구를 사용해보고 싶었던 분들이 사용해보시면 좋을 것 같아요 :)");
		fpvo.setFreePdt("미니선반 DIY키트");
		fpvo.setFpPeople(6);
		fpvo.setFpDeadline("2023/10/20");
		fpvo.setFpState(1);
		fpvo.setFpGetDate("2023/10/25");
		fpvo.setFpGetPlace("호미 본사 2층 시청각실");
		fpvo.setMid("tester");
		fpvo.setFpImg("이미지 주소");

		log.info("UPDATE COUNT : " + freePdtMapper.fpUpdate(fpvo));
	}
	
	
	public void testInsert() {		//제품 나눔 게시글 추가 테스트
		FreePdtVO fpvo = new FreePdtVO();
		
		fpvo.setFpTitle("직접 만든 나만의 가구를 만들어보자! 미니선반 DIY키트 나눔");
		fpvo.setFpContent("저희 HOMEY에서 <OO에디션 미니선반 DIY키트> 를 나눔합니다~\r\n"
								+ "OOO에 있어서 OOO 때문에 고민이셨던 분, OO한 자신만의 가구를 사용해보고 싶었던 분들이 사용해보시면 좋을 것 같아요 :)");
		fpvo.setFreePdt("미니선반 DIY키트");
		fpvo.setFpPeople(6);
		fpvo.setFpDeadline("2023/10/20");
		fpvo.setFpGetDate("2023/10/25");
		fpvo.setFpGetPlace("호미 본사 2층 시청각실");
		fpvo.setMid("tester");
		fpvo.setFpImg("이미지 주소");

		freePdtMapper.fpInsert(fpvo);
		log.info("--------------------------");
		log.info(fpvo);
	}

	
}
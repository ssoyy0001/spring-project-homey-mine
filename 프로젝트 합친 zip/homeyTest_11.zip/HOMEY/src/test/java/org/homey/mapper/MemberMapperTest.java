package org.homey.mapper;

import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.sql.DataSource;

import org.homey.domain.MemberVO;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import lombok.Setter;
import lombok.extern.log4j.Log4j;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration({
	"file:src/main/webapp/WEB-INF/spring/root-context.xml",
	"file:src/main/webapp/WEB-INF/spring/security-context.xml" })
@Log4j
public class MemberMapperTest {
	
	@Setter(onMethod_ =@Autowired )
	private MemberMapper memberMapper;
	@Setter(onMethod_ =@Autowired )
	private PasswordEncoder pwEncoder;
	@Setter(onMethod_ =@Autowired )
	private DataSource dataSource;
	private PreparedStatement pstmt;
	
	
	@Test
	public void memberinsertTest(){						//insert 할 때마다 비밀번호 1111로 넣음
		MemberVO mvo=new MemberVO();
		mvo.setMid("user");
		mvo.setPw(pwEncoder.encode("1111"));
		mvo.setMaddr("test");
		mvo.setMphone("010-1111-1111");
		mvo.setMemail("test@test.test");
		mvo.setMname("회원");
		memberMapper.insert(mvo);
	}
	
	
	public void testSelect() {
		MemberVO mvo=memberMapper.select("admin");
		log.info(mvo);
	}
	
	
	public void testInsertAuth() {
		String sql="";
		//0~79 일반 사용자 user0~user79
		//80~89 멤버 member80~member 89
		//90~99 관리자 admin90~admin99
		sql="INSERT INTO memberauth(mid,auth) VALUES(?,?)";
		try {
			pstmt=dataSource.getConnection().prepareStatement(sql);
			
		
				pstmt.setString(1, "admin");
				pstmt.setString(2,"ROLE_ADMIN");
			
				pstmt.executeUpdate();
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	


}

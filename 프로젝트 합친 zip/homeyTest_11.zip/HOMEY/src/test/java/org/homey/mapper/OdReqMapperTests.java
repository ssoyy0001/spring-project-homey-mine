package org.homey.mapper;


import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import org.homey.domain.OdReqVO;

import lombok.Setter;
import lombok.extern.log4j.Log4j;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration("file:src/main/webapp/WEB-INF/spring/root-context.xml")
@Log4j
public class OdReqMapperTests {
	
	@Setter(onMethod_ = @Autowired)
	private OdReqMapper odReqMapper;
	
	@Test
	public void testSelectMine() {		//나의 원데이클래스 신청목록 조회
		
	log.info("--------------------------");
	odReqMapper.odReqSelectMine("user000000").forEach(odrvo -> log.info(odrvo));
		
	}
	
	public void testSelectWin() {		//나의 원데이클래스 당첨자 목록 조회
		
		log.info("--------------------------");
		odReqMapper.odWinSelect(11).forEach(odrvo -> log.info(odrvo));
		
	}
	
	
	public void testSelect() {						//원데이클래스 신청서 개별조회 테스트
		log.info("--------------------------");
		log.info(odReqMapper.odReqSelect(3));
		log.info("--------------------------");
	
	}
	
	
	public void testOdReqWinX() {		//원데이클래스 당첨철회 (관리자롤)
		log.info("UPDATE COUNT : " + odReqMapper.odReqWinX(4));
	}
	
	
	public void testOdReqWin() {		//원데이클래스 당첨자 선정
		log.info("UPDATE COUNT : " + odReqMapper.odReqWin(4));
	}

	
	
	public void testDelete() {		//원데이클래스 신청서 철회 테스트
		log.info("DELETE COUNT : " + odReqMapper.odReqDelete(5));
	}
	
	
	



	
	
	public void testSelectAll() {		//특정 원데이클래스의 신청자 전체조회 테스트
	
	log.info("--------------------------");
	odReqMapper.odReqSelectAll(10).forEach(odrvo -> log.info(odrvo));
		
	}
	

	public void testDoubleCheck() {		//원데이클래스 중복신청 여부 확인 테스트
		
		log.info("--------------------------");
		log.info("중복 건수 : " + odReqMapper.doubleCheck(10, "tester"));		// 1 출력됨

	}
	
	
	public void testInsert() {						//원데이클래스 신청 등록 테스트
		
		OdReqVO odrvo = new OdReqVO();
		
		odrvo.setOdNo(11);
		odrvo.setMid("tester");
		odrvo.setOdReqTitle("호미 소가구 DIY 클래스 신청합니다.");
		odrvo.setOdReqContent("평소에 소가구 DIY하는 걸 취미로 즐기고 있었는데요.\r\n"
										+ "호미에서 진행하는 DIY 클래스 안내글을 보니까 OOOOO해보고 싶어서 클래스 신청합니다.");
	
		odReqMapper.odReqInsert(odrvo);
		log.info("--------------------------");
		log.info(odrvo);
	}


	
}
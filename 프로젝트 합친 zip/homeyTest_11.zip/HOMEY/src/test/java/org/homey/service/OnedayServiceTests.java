package org.homey.service;

import static org.junit.Assert.assertNotNull;

import org.homey.domain.SoCriteria;
import org.homey.domain.OnedayVO;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import lombok.Setter;
import lombok.extern.log4j.Log4j;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration("file:src/main/webapp/WEB-INF/spring/root-context.xml")
@Log4j
public class OnedayServiceTests {
	
	@Setter(onMethod_ = @Autowired)
	private OnedayService onedayService;
	
	@Test
	public void testModify() {
		
		OnedayVO odvo = onedayService.odView(14);
		
		if(odvo == null) {			//bno가 1인 게시물이 없다면 리턴
			return;
		}
		
		odvo.setOdTitle("(수정테스트)소가구 DIY 원데이클래스 진행합니다~");
		odvo.setOdContent("안녕하세요! 저희 HOMEY에서 <스타일링별 가구 배치 원데이클래스> 를 진행합니다. ^^\r\n"
									+ "OOO에 있어서 OOO 때문에 고민이셨던 분들이 참여해보시면 좋을 것 같아요~ \r\n"
									+ "OOO에서 ㅁㅁㅁㅁ로 활동중이신 김땡땡 전문가님이 진행하시는 클래스입니다.\r\n");
		odvo.setOdName("소가구 DIY 원데이클래스");
		odvo.setOdDate("2023-10-17 14:00");
		odvo.setOdPlace("호미 본사 2층 시청각실");
		odvo.setOdTime("1시간 30분");
		odvo.setOdPeople(4);
		odvo.setOdMc("김OO님");
		odvo.setOdDeadline("2023-10-24");
		
		odvo.setOdState(0);
		odvo.setMid("tester");
		odvo.setOdImg("이미지 주소");
		
		log.info("UPDATE RESULT : " + onedayService.odModify(odvo));
	}
	
	
	
	public void testRemove() {
		log.info("DELETE RESULT : " + onedayService.odRemove(16));
	}
	
	
	public void testRegister() {
		
		OnedayVO odvo = new OnedayVO();
		
		odvo.setOdTitle("분위기별 가구 컬러조합 원데이클래스 진행합니다~");
		odvo.setOdContent("저희 HOMEY에서 <가구 컬러조합 원데이클래스> 를 진행합니다. ^^\r\n"
									+ "OOO에 있어서 OOO 때문에 고민이셨던 분들이 참여해보시면 좋을 것 같아요~ \r\n"
									+ "OOO에서 ㅁㅁㅁㅁ로 활동중이신 김땡땡 전문가님이 진행하시는 클래스입니다.\r\n");
		odvo.setOdName("가구 컬러조합 원데이클래스");
		odvo.setOdDate("2023-10-18 14:00");
		odvo.setOdPlace("호미 본사 2층 시청각실");
		odvo.setOdTime("1시간 30분");
		odvo.setOdPeople(4);
		odvo.setOdMc("김OO님");
		odvo.setOdDeadline("2023-10-25");
		
		odvo.setOdState(0);
		odvo.setMid("tester");
		odvo.setOdImg("이미지 주소");

		
		log.info("등록 성공 : " + onedayService.odRegister(odvo) ) ;
	}
	
	
	public void testView() {
		log.info(onedayService.odView(14));
	}
	
	public void testListPaging() {							//원데이클래스 게시글 전체조회
		log.info("-------------------------");
		SoCriteria cri = new SoCriteria(2, 2);
		onedayService.odListPaging(cri).forEach(ovo -> log.info(ovo));
		log.info("-------------------------");
	}
	
	
	public void testCount() {									//원데이클래스 게시글 개수
		log.info("-------------------------");
		SoCriteria cri = new SoCriteria();
		log.info(onedayService.odTotalCount(cri));
		log.info("-------------------------");
		
	}
	
	public void testExist() {									//OnedayService가 잘 만들어졌는지 확인
		assertNotNull(onedayService);		
		log.info(onedayService);
	}
	

}

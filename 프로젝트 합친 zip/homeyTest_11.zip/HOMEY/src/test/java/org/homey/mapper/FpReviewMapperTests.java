package org.homey.mapper;


import org.homey.domain.FpReviewVO;
import org.homey.domain.OdReviewVO;
import org.homey.domain.SoCriteria;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;


import lombok.Setter;
import lombok.extern.log4j.Log4j;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration("file:src/main/webapp/WEB-INF/spring/root-context.xml")
@Log4j
public class FpReviewMapperTests {
	
	@Setter(onMethod_ = @Autowired)
	private FpReviewMapper fpReviewMapper;
	
	@Test
	public void testSelectMine() {		//내가 쓴 리뷰 전체조회 테스트
		
		SoCriteria c = new SoCriteria();
	    
		log.info("--------------------------");
		fpReviewMapper.selectMine("ssoyy00010001", c).forEach(prvo -> log.info(prvo));			//람다 사용해서 한 줄씩 나오도록
		
	}
	
	
	public void testMineCount() {		//내가 쓴 리뷰 개수 테스트
		
		SoCriteria c = new SoCriteria();
		
		log.info("--------------------------");
		log.info(fpReviewMapper.mineCount("ssoyy00010001", c));
		
	}
	
	
	public void testCount() {		//리뷰 전체 개수 테스트
		SoCriteria c = new SoCriteria();	
		
		log.info("--------------------------");
		log.info(fpReviewMapper.totalCount(c));
		
	}
	
	
	public void testUpdate() {		//메서드 이름 자유, 게시글 수정 메서드
		FpReviewVO prvo = fpReviewMapper.select(6);
		
		prvo.setPrTitle("내가 작성했던 게시글 수정");
		prvo.setPrContent("내가 작성한 제품 나눔 게시글 내용수정중");
		
		log.info("UPDATE COUNT : " + fpReviewMapper.update(prvo));
	}
	
	
	
	public void testSelect() {		//메서드 이름 자유, 개별조회 메서드
		log.info("--------------------------");
		log.info(fpReviewMapper.select(5));		//No는 일단 임의로 씀
		log.info("--------------------------");
	}
	
	
	
	
	public void testDelete() {		//메서드 이름 자유, 게시글 삭제 메서드
		log.info("DELETE COUNT : " + fpReviewMapper.delete(7));
	}
	
	
	public void testUpdateHit() {
		
		log.info("--------------------------");
		log.info("UPDATEHIT COUNT : " + fpReviewMapper.updateHit(7));
		
	}
	
	
	
	public void testSelectAllPaging() {		//메서드 이름 자유, 페이징 전체조회 메서드
		
		SoCriteria c = new SoCriteria(8,1);	//amount 2, pageNum 2 로 테스트해봄
		fpReviewMapper.selectAllPaging(c).forEach(prvo -> log.info(prvo));			//람다 사용해서 한 줄씩 나오도록
		
		log.info("--------------------------");
		log.info("전체 게시물 수 : " + fpReviewMapper.totalCount(c));
		log.info("--------------------------");
	}
	
	
	
	public void testInsert() {		//리뷰 등록 테스트
		FpReviewVO prvo = new FpReviewVO();
		
		prvo.setMid("ssoyy00010001");
		prvo.setFpNo(56);
		prvo.setPrTitle("미니선반 DIY키트 나눔받은 후기 ㅎㅎ");
		prvo.setPrContent("미니선반 DIY키트 나눔받았는데 너무 실용적이에요. \n잘 사용하겠습니다~");

		fpReviewMapper.insertSelectKey(prvo);
		
		log.info("--------------------------");
		log.info(prvo);
	}


	
}
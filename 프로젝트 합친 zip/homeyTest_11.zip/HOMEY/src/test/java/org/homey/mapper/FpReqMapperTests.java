package org.homey.mapper;


import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import org.homey.domain.FPReqVO;

import lombok.Setter;
import lombok.extern.log4j.Log4j;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration("file:src/main/webapp/WEB-INF/spring/root-context.xml")
@Log4j
public class FpReqMapperTests {
	
	@Setter(onMethod_ = @Autowired)
	private FpReqMapper fpReqMapper;
	
	@Test
	public void testSelectWin() {		//특정 제품 나눔 게시글의 신청목록

		//“제품나눔 당첨자 목록” 화면에서 띄워야 할 것 : 로우넘 , 당첨자ID, 당첨자이름, 이메일, 연락처 -> 그럼 다 된 거인듯?
		log.info("--------------------------");
		log.info(fpReqMapper.fpWinSelect(1));				//1번 제품 나눔 게시글의 신청자 목록 조회
		log.info("--------------------------");
	}
	
	
	public void testSelectMine() {		//나의 나눔 신청목록

		log.info("--------------------------");
		log.info(fpReqMapper.fpSelectMine("tester"));				//2번 제품 나눔 게시글의 신청자 목록 조회
		log.info("--------------------------");
	}
	
	
	public void testSelectWinAll() {		//모든 제품 나눔 게시글의 신청목록

		log.info("--------------------------");
		log.info(fpReqMapper.fpWinSelectAll());				//2번 제품 나눔 게시글의 신청자 목록 조회
		log.info("--------------------------");
	}
	
	
	
	public void testDoubleCheck() {		//제품 나눔 중복신청 여부 확인 테스트
			
		log.info("--------------------------");
		log.info("중복 건수 : " + fpReqMapper.fpReqCheck(1, "testerrrrr"));		// 0 출력됨

	}
	
	
	public void testInsert() {		//제품 나눔 신청 등록 테스트
		FPReqVO fprvo = new FPReqVO();
		
		fprvo.setFpNo(2);
		fprvo.setMid("tester");
		
		fpReqMapper.fpReqInsert(fprvo);
		log.info("--------------------------");
		log.info(fprvo);
	}

	
}
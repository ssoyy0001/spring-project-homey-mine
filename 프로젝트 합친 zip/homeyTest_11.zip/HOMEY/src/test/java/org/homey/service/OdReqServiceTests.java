package org.homey.service;

import static org.junit.Assert.assertNotNull;

import org.homey.domain.OdReqVO;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;

import lombok.Setter;
import lombok.extern.log4j.Log4j;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration("file:src/main/webapp/WEB-INF/spring/root-context.xml")
@Log4j
public class OdReqServiceTests {
	
	@Setter(onMethod_ = @Autowired)
	private OdReqService odReqService;
	
	@Test
	public void testListWin() {								//나의 원데이클래스 신청목록 조회
		
		log.info("--------------------------");
		odReqService.odWinList(10).forEach(odrvo -> log.info(odrvo));
			
	}
	
	
	public void testOdReqWin() {							//원데이클래스 당첨철회 (관리자롤)
		log.info("UPDATE COUNT : " + odReqService.odReqWin(6));
	}
	
	
	public void testOdReqWinX() {							//원데이클래스 당첨철회 (관리자롤)
		log.info("UPDATE COUNT : " + odReqService.odReqWinX(6));
	}
	
	
	
	public void testView() {									//원데이클래스 신청자 상세조회
		log.info("--------------------------");
		log.info(odReqService.odReqView(6));
		log.info("--------------------------");
	}
	
	
	public void testRemove() {								//원데이클래스 신청철회
		log.info("DELETE RESULT : " + odReqService.odReqRemove(4));
	}
	
	
	public void testListMine() {								//나의 원데이클래스 신청목록 조회
		
		log.info("--------------------------");
		odReqService.odReqListMine("tester").forEach(odrvo -> log.info(odrvo));
			
	}
	
	
	public void testListPaging() {							//특정 원데이클래스의 신청자 전체조회 테스트
		
		log.info("--------------------------");
		odReqService.odReqList(11).forEach(odrvo -> log.info(odrvo));
			
	}
	
	
	public void testDoubleCheck() {						//원데이클래스 중복신청 여부 확인 테스트
		
		log.info("--------------------------");
		log.info("중복 건수 : " + odReqService.doubleCheck(12, "tester"));		// 1 출력됨

	}
	
	
	public void testRegister() {								//원데이클래스 신청
		
		OdReqVO odrvo = new OdReqVO();
		
		odrvo.setOdNo(11);
		odrvo.setMid("tester");
		odrvo.setOdReqTitle("가구 색상 조합 클래스 신청합니다.");
		odrvo.setOdReqContent("평소에 소가구 DIY하는 걸 취미로 즐기고 있었는데요.\r\n"
										+ "호미에서 진행하는 DIY 클래스 안내글을 보니까 OOOOO해보고 싶어서 클래스 신청합니다.");
	
		log.info("등록 성공 : " + odReqService.odReqRegister(odrvo));
	}
	
	
	public void testExist() {									//odReqService가 잘 만들어졌는지 확인
		assertNotNull(odReqService);		
		log.info(odReqService);
	}
	

}

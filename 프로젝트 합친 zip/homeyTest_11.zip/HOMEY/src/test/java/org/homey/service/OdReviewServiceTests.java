package org.homey.service;

import static org.junit.Assert.assertNotNull;

import org.homey.domain.OdReviewVO;
import org.homey.domain.SoCriteria;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.test.context.ContextConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;


import lombok.Setter;
import lombok.extern.log4j.Log4j;

@RunWith(SpringJUnit4ClassRunner.class)
@ContextConfiguration("file:src/main/webapp/WEB-INF/spring/root-context.xml")
@Log4j
public class OdReviewServiceTests {
	
	@Setter(onMethod_ = @Autowired)
	private OdReviewService odReivewService;
	
	
	@Test
	public void testRemove() {
		log.info("DELETE RESULT : " + odReivewService.remove(10));
	}
	
	
	public void testModify() {
		OdReviewVO orvo = odReivewService.view(10);
		
		if(orvo == null) {			//bno가 1인 게시물이 없다면 리턴
			return;
		}
		orvo.setOrTitle("호미호미 클래스를 수정");
		orvo.setOrContent("호미호미 클래스 리뷰 후기를 수정중");
		
		log.info("UPDATE RESULT : " + odReivewService.modify(orvo));
	}
	
	
	
	public void testView() {
		log.info(odReivewService.view(10));
	}
	
	
	public void testListMine() {
		
		log.info("-------------------------");
		SoCriteria cri = new SoCriteria();
		odReivewService.listMine("user111111", cri).forEach(orvo -> log.info(orvo));
		log.info("-------------------------");
		
	}
	
	
	public void testList() {
	
		log.info("-------------------------");
		SoCriteria cri = new SoCriteria();
		odReivewService.listPaging(cri).forEach(orvo -> log.info(orvo));
		log.info("-------------------------");
		log.info(odReivewService.totalCount(cri));
		
	}
	
	
	public void testRegister() {
		
		OdReviewVO orvo = new OdReviewVO();
		orvo.setMid("user111111");
		orvo.setOdNo(121);
		orvo.setOrTitle("호미호미클래스 후기");
		orvo.setOrContent("호미호미클래스 후기 작성!!! \\n유용했어요~.");

		
		odReivewService.register(orvo);
		
		log.info("생성된 게시물 번호 : " + orvo.getOdNo());
	}

	
	public void testExist() {
		assertNotNull(odReivewService);		//odReivewService가 만들어졌는지 확인
		log.info(odReivewService);
	}
	
}
